
/**
 * Esta clase representa una condicion de una excepcion en la cual las dimensiones de una matriz son mas de las que se pueden manejar
 * 
 * @author Carlos Lopez y Jefry Turcios
 * @version 01.02.09
 */
public class MuchasDimensiones extends Exception
{
    private int numerodefilas;
    private int numerodecolumnas;
    
    /**
     * Configura el objeto de la excepcion con algun mensaje de error
     */
    MuchasDimensiones(String mensaje)
    {
        super(mensaje);
    }
    
    /**
     * Metodo para establecer la cantidad de filas de la matriz
     * 
     * @param numerodefilas La cantidad de filas de la matriz
     */
    public void setNumerodeFilas(int numerodefilas){
        this.numerodefilas = numerodefilas;
    }
    
    /**
     * Metodo para devolver la cantidad de filas de la matriz
     * 
     * @return La cantidad de filas de la matriz
     */
    public int getNumerodeFilas(){
        return this.numerodefilas;
    }

    /**
     * Metodo para establecer la cantidad de columnas de la matriz
     * 
     * @param numerodecolumnas La cantidad de columnas de la matriz
     */
    public void setNumerodeColumnas(int numerodecolumnas){
        this.numerodecolumnas = numerodecolumnas;
    }
    
    /**
     * Metodo para devolver la cantidad de columnas de la matriz
     * 
     * @return La cantidad de columnas de la matriz
     */
    public int getNumerodeColumnas(){
        return this.numerodecolumnas;
    }
}


/**
 * Esta clase representa una condicion de una excepcion en la cual las dimensiones de una matriz estan mal ingresadas
 * 
 * @author Carlos Lopez y Jefry Turcios
 * @version 01.02.09
 */
public class DimensionesIncorrectas extends Exception
{
    int numerodefilaenquefallo;
    
    /**
     * Configura el objeto de la excepcion con algun mensaje de error
     */
    DimensionesIncorrectas(String mensaje)
    {
        super(mensaje);
    }

    /**
     * Metodo para establecer la fila en donde fallo
     * 
     * @param la fila en donde fallo
     */
    public void setNumerodeFilaenDondeFallo(int numerodefilaquefallo){
        this.numerodefilaenquefallo = numerodefilaquefallo;
    }
   
    /**
     * Metodo para devolver la fila en que fallo
     * 
     * @return la fila en que fallo
     */
    public int getNumerodeFilaenDondeFallo(){
        return this.numerodefilaenquefallo;
    }
}


/**
 * 
 * 
* @author Carlos Lopez Camey & Jeffry Turcios
 * @version 01.02.2009
 */
import java.util.*;
import java.util.ArrayList;

public class Lab2
{
    String Letras;
    ArrayList<Matriz> Matrices;
    Matriz Respuesta;

    /**
     * Constructor de la clase Lab2
     * 
     * @throws expresionIncorrecta si se ingresa una expresion de matriz cuyo numero de "[" es diferente al numero de "]" 
     * @throws DimensionesIncorrectas si se ingresa una matriz cuyo numero de columnas no es igual en todas las filas ingresadas
     * @throws MuchasDimensiones si se ingresa una matriz cuyo numero de filas o el numero de columnas es mayor a 10 
     * @throws CaracterInvalido si ingreso un numero no entero, una letra o un caracter invalido como dato de la matriz ingresada
     */
    public Lab2() throws expresionIncorrecta, DimensionesIncorrectas, MuchasDimensiones, CaracterInvalido
    {
        Scanner teclado = new Scanner (System.in);
        boolean nohasalido = true;
        Matrices = new ArrayList<Matriz>();
        Letras = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        EscribirMenu();
        while (nohasalido){
            int decision;
            try {
                decision = Integer.parseInt(teclado.nextLine());
                switch (decision){
                    //quiere agregar una nueva matriz
                    case 1:{
                        if (Matrices.size()<30){
                            System.out.println("La notacion para ingresar matrices es la siguiente:");
                            System.out.println("[u1 u2 u3][u4 u5 u6]");
                            System.out.println("Esta matriz representaria a la siguiente matriz de 2 filas y de 3 columnas");
                            System.out.println("u1\tu2\tu3\nu4\tu5\tu6");
                           try {
                                System.out.println("Ahora usted ingresara la matriz denominada con la literal \""+Letras.substring(Matrices.size(),Matrices.size()+1)+"\": ");
                                Matrices.add(new Matriz(teclado.nextLine()));
                            }catch (expresionIncorrecta expresionmalBalanceada){
                                System.out.println("Porfavor ingrese bien su matriz, se produjo un error: "+expresionmalBalanceada);
                                System.out.println("Usted ingreso "+Integer.toString(expresionmalBalanceada.getNumerodeCorchetesAbiertos())+" corchetes abiertos y "+Integer.toString(expresionmalBalanceada.getNumerodeCorchetesCerrados())+" cerrados, su expresi�n est� mal balanceada");
                            }
                            catch (DimensionesIncorrectas numeroDistintodeColumnas){
                                System.out.println("Porfavor ingrese bien su matriz, se produjo un error: "+numeroDistintodeColumnas);
                                System.out.println("La fila numero "+Integer.toString(numeroDistintodeColumnas.getNumerodeFilaenDondeFallo())+" no tiene la misma cantidad de datos que la primera fila");
                            }catch (MuchasDimensiones muchasDimensiones){
                                System.out.println("La matriz que usted ingreso tiene "+Integer.toString(muchasDimensiones.getNumerodeFilas())+" filas y "+Integer.toString(muchasDimensiones.getNumerodeColumnas())+" columnas, solo se permiten matrices de 10filas x 10columnas");
                            }catch (CaracterInvalido caracterInvalido){
                                System.out.println("Porfavor ingrese bien su matriz, se produjo un error: "+caracterInvalido);
                                System.out.println("Usted ingreso "+caracterInvalido.getDatoInvalido() +" en la fila "+Integer.toString(caracterInvalido.getFilaenDondeEstaElDatoInvalido())+", un dato no entero");
                            }
                        } else {
                            System.out.println("Usted ya ingreso demasiadas matrices (un m�ximo de 30)");
                        }
                    } break;
                    case 2:{
                        try{
                        System.out.println("Ingrese la expresion en Prefix porfavor (Ejemplo: +AB)"); 
                        Matriz Respuesta = new Matriz(EvaluarExp(teclado.nextLine()).Matriz);
                        Respuesta.escribirMatriz();
                    } catch(Exception error) {
                        System.out.println("Error en el intentar evaluar "+error);
                    }
                    } break;
                    case 3:{
                        System.out.println("Ingrese la literal con la que esta denominada su matriz para eliminarla: ");
                        String literal = teclado.nextLine();
                        
                        //ver si tiene length 1 y ver si es letra
                        if ((literal.trim().length()!=1) || (Letras.indexOf(literal.trim().toUpperCase())==(-1)))
                            System.out.print("Ingrese una literal porfavor (A,B,C,D...)");
                        else {
                            //si esta matriz existe..
                            if (Letras.indexOf(literal.trim().toUpperCase())<Matrices.size()){
                                Matrices.remove(Letras.indexOf(literal.trim().toUpperCase()));
                            }
                            else
                                System.out.println("Usted todavia no ha ingresado esa matriz, o borro alguna y recuerde que todas se corren (si borro \"A\" ahora esta tendra el contenido de \"B\" y asi sucesivamente)");
                        }
                    } break;
                    case 4:{
                        System.out.println("Ingrese la literal con la que esta denominada su matriz: ");
                        String literal = teclado.nextLine();
                        
                        //ver si tiene length 1 y ver si es letra
                        if ((literal.trim().length()!=1) || (Letras.indexOf(literal.trim().toUpperCase())==(-1)))
                            System.out.print("Ingrese una literal porfavor (A,B,C,D...)");
                        else {
                            //si esta matriz existe..
                            if (Letras.indexOf(literal.trim().toUpperCase())<Matrices.size()){
                                Matrices.get(Letras.indexOf(literal.trim().toUpperCase())).escribirMatriz();
                            }
                            else
                                System.out.println("Usted todavia no ha ingresado esa matriz, o borro alguna y recuerde que todas se corren (si borro \"A\" ahora esta tendra el contenido de \"B\" y asi sucesivamente)");
                        }
                    } break;
                    //quiso salir 
                    case 5:{
                        nohasalido = false; 
                    } break;
                    //otra cosa que nada que ver
                    default: {
                        System.out.println("Ingrese algun numero que corresponda al menu");
                    }
                }
            }
            catch (Exception error){
                System.out.println("Ingrese algun numero que corresponda al menu, usted ingreso una letra o caracter que no lo hacen");
            }
            finally {
                EscribirMenu();
            }
        }
    }

    /**
     * Metodo que escribe el menu
     * 
     */
     private void EscribirMenu(){
        System.out.println("******************** MENU ******************** ");
        System.out.println("1. Ingresar Matriz");
        System.out.println("2. Operar Matrices (En postfix)");
        System.out.println("3. Borrar Matriz");
        System.out.println("4. Ver la expresion de una matriz");
        System.out.println("5. Salir del programa");
        System.out.print("Que quiere hacer? \nIngrese el numero que corresponda a continuacion: ");
    }
    
    /**
     * Metodo que evalua la expresion
     * 
     * @params exp La expresion en Prefix a evaluar
     * @throws MatricesNoCompatibles si a la hora de multiplicar o sumar, estas no se realizan debido a incompatibilidad (Ver metodos de Sumar y Multiplicar en Matriz)
     */
    private Matriz EvaluarExp(String exp) throws MatricesNoCompatibles
    {
        if ((exp.charAt(0)>='A') && (exp.charAt(0) <= 'Z'))
        {
            return(Matrices.get(Letras.indexOf(exp.charAt(0))));
        }
        
        switch (exp.charAt(0))
        {
            case '+': {
                System.out.println("exp.substring(1): "+exp.substring(1));
                System.out.println("exp.substring(2): "+exp.substring(2));
                return(EvaluarExp(exp.substring(1)).SumarlaCon(EvaluarExp(exp.substring(2))));
            }
            case '*': return(EvaluarExp(exp.substring(1)).MultiplicarlaPor(EvaluarExp(exp.substring(2))));
        }
        return Matrices.get(Letras.indexOf('A'));
    }
}

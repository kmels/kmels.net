
/**
 * Esta clase define a una matriz
 * 
 * @author Carlos Eduardo L�pez Camey y Jeffry Turcios
 * @version 01.02.2009
 */
public class Matriz
{
    //definir las variables
    //la matriz de esta clase
    public int [][] Matriz;
    //la expresion que representa a esta matriz
    public String expresion;
    //vector de filas de la clase fila
    private Fila[] filas;
    //numero de filas y numero de columas que tiene esta matriz
    public int numerodefilas;
    public int numerodecolumnas;
    
    /**
     * Constructor de la clase Matriz, inicializa la matriz a partir de una expresion
     * 
     * @param  expresion la expresion en la forma que esta especificada en el programa, ejemplo: [u1 u2][u3 u4]
     * @throws expresionIncorrecta si el numero de "[" es diferente al numero de "]"
     * @throws DimensionesIncorrectas si el numero de columnas no es igual en todas las filas ingresadas
     * @throws MuchasDimensiones si el numero de filas o el numero de columnas es mayor a 10 
     * @throws CaracterInvalido si ingreso un numero no entero, una letra o un caracter invalido como dato de la matriz
     */
    public Matriz(String expresion) throws expresionIncorrecta, DimensionesIncorrectas, MuchasDimensiones, CaracterInvalido
    {
        //quitar los espacios en blanco de m�s
        this.expresion = expresion.trim();
        
        //chequear que el numero de [ sea el mismo que el numero de ]
        if ((contarCaracteres("[",this.expresion))!=(contarCaracteres("]",this.expresion))){
            expresionIncorrecta malIngresado = new expresionIncorrecta("La expresi�n que usted ingreso est� mal ingresada, cuente bien las veces que ud. ingreso \"[\" y \"]\", las ingreso diferente numero de veces"); 
            malIngresado.setNumerodeCorchetesAbiertos(contarCaracteres("[",this.expresion));
            malIngresado.setNumerodeCorchetesCerrados(contarCaracteres("]",this.expresion));
            throw malIngresado;
        }
       
        //establecer numero de filas de la matriz
        this.numerodefilas = contarCaracteres("[",this.expresion);
        
        //crear el vector de filas del tama�o de numero de filas ingresadas
        filas = new Fila[numerodefilas];
        
        //inicializar expresion restante
        String expresionRestante = expresion;
        
        //vamos a usar a meter las filas en cada objeto de fila correspondiente
        for (int i=0;i<this.numerodefilas;i++){
                //encontrar posiciones de los corchetes y guardarlas
                int POSprimercorcheteabierto = expresionRestante.indexOf("[");
                int POSprimercorchetecerrado = expresionRestante.indexOf("]");
                
                //tomar el string de los valores adentro de los corchetes 
                String valores = expresionRestante.substring(POSprimercorcheteabierto+1,POSprimercorchetecerrado);
                //crear la fila con el conunto de valores
                filas[i] = new Fila(valores);
              
                //agarrar el string despues del ] si tdavia hay mas
                if (i<(this.numerodefilas-1))
                    expresionRestante = expresionRestante.substring(POSprimercorchetecerrado+1);
        }
        
        //establecer el numero de columnas en la primera fila para comparar con esta
        int numerodecolumnasEnFila1 = filas[1].columnas.size();
                  
        //vamos a chequear si todas las filas tienen el mismo numero de columas, si hay uno distinto, tira error de numero de columas distinto
        for (int i=0;i<this.numerodefilas;i++){
                if (numerodecolumnasEnFila1!=filas[i].columnas.size()){
                    DimensionesIncorrectas numerodeColumnasDistinto = new DimensionesIncorrectas("El conjunto de filas que usted ingreso no tienen la misma cantidad de datos (columnas)"); 
                    numerodeColumnasDistinto.setNumerodeFilaenDondeFallo(i);
                    throw numerodeColumnasDistinto;
                }
        }
        this.numerodecolumnas = numerodecolumnasEnFila1;
        
        //ver si el numero de columnas en las filas es menor o igual que 10 (lo permitido), si no, tirar error
        if (((this.numerodecolumnas)>10) || (numerodefilas>10)){
            MuchasDimensiones muchasDimensiones = new MuchasDimensiones("Usted ingreso una matriz de muchas dimensiones, lo maximo que procesara este programa es de 10x10");
            throw muchasDimensiones;
        }
        
        //la matriz esta perfectamente ingresada, vamos a llenarla
        Matriz = new int[this.numerodefilas][this.numerodecolumnas];
        for (int fila=0;fila<this.numerodefilas;fila++)
            for (int columna=0;columna<this.numerodecolumnas;columna++){
                Matriz[fila][columna] = filas[fila].columnas.get(columna);
            }
    }

    /**
     * Constructor de la clase Matriz, inicializa la matriz a partir de una matriz de enteros
     * 
     * @param  matriz la martriz de enteros (int[][])
     */
    public Matriz(int[][] matriz){
        

        this.numerodefilas = matriz.length;
        this.numerodecolumnas = matriz[0].length;
        this.Matriz = new int[numerodefilas][numerodecolumnas];
        
        for (int fila=0;fila<this.numerodefilas;fila++){
            for (int columna=0;columna<this.numerodecolumnas;columna++){
                    this.Matriz[fila][columna] = matriz[fila][columna];
            }
        }
    }
    /**
     * Metodo que cuenta el numero de caracteres en un String
     * 
     * @param  caracter el String que se quiere contar
     * @param expresion el String en donde se desea buscar
     * @return el numero de veces que encontro el caracter en la expresion
     */
    private int contarCaracteres(String caracter,String expresion){
        String expresionRestante = expresion;
        int cuantasveces = 0;
        
        //mientras el caracter est� en la expresion
        while (expresionRestante.indexOf(caracter)!=(-1)){
            cuantasveces++;
            
            //si todav�a hay mas expresion para seguir encontrando el caracter
            if ((expresionRestante.indexOf(caracter)+1)<(expresionRestante.length()))
                expresionRestante = expresionRestante.substring(expresionRestante.indexOf(caracter)+1);
            else 
                expresionRestante = "";
        }   
        return cuantasveces;
    }
    
    /**
     * Metodo para escribir la matriz
     * 
     */
    public void escribirMatriz(){
        
        for (int fila=0;fila<numerodefilas;fila++){
            for (int columna=0;columna<numerodecolumnas;columna++){
                System.out.print(Integer.toString(Matriz[fila][columna])+"\t");
            }
            System.out.println("");
        }
    }
    
    /**
     * Metodo para sumar matrices
     * 
     * @param  MatrizTemp de la clase Matriz, es la matriz 2 con la que se sumara esta matriz
     * @return la matriz resultado de la suma entre esta matriz y la matriz 2
     * @throws MatricesNoCompatibles si las dimensiones de esta matriz es diferente a las dimensiones de la matriz 2
     */
    public Matriz SumarlaCon(Matriz MatrizTemp) throws MatricesNoCompatibles
	{  
		int[][] matrizResultado = new int[this.numerodefilas][this.numerodecolumnas];
		
		if ((this.numerodefilas!=MatrizTemp.numerodefilas) || (this.numerodecolumnas!=MatrizTemp.numerodecolumnas)){
		    MatricesNoCompatibles NoCoinciden = new MatricesNoCompatibles("Las matrices que usted esta intentando sumar no tienen el mismo numero de filas y/o de columnas");
			throw NoCoinciden;
			}   
		
		for(int i = 0; i < this.numerodefilas; i++)
			for (int j = 0; j < this.numerodecolumnas; j++)
				matrizResultado[i][j] = this.Matriz[i][j] + MatrizTemp.Matriz[i][j];
				
		Matriz Resultado = new Matriz(matrizResultado);
		
		return (Resultado);
	}

    /**
     * Metodo para multiplicar matrices
     * 
     * @param  MatrizTemp de la clase Matriz, es la matriz 2 con la que se multiplicara esta matriz
     * @return la matriz resultado de la multiplicacion entre esta matriz y la matriz 2
     * @throws MatricesNoCompatibles si el numero de columnas de esta matriz es diferente que el numero de filas de la matriz 2 
     */
	public Matriz MultiplicarlaPor(Matriz MatrizTemp) throws MatricesNoCompatibles{
		if (this.numerodecolumnas != MatrizTemp.numerodefilas){
		    MatricesNoCompatibles NoCoinciden = new MatricesNoCompatibles("Las matrices que usted esta intentando multiplicar no tienen el mismo numero de filas que de columnas");
			throw NoCoinciden;
        }

		int[][] prueba = new int[this.numerodefilas][MatrizTemp.numerodecolumnas];
		//System.out.println("numero de filas= "+this.numerodefilas+" numero de columnas= "+MatrizTem.numerodecolumnas);
		
		Matriz Resultado = new Matriz(prueba);
		int numero = 0;
		
		for (int i = 0; i < this.numerodefilas; i++)
		{
			for (int j = 0; j < MatrizTemp.numerodecolumnas; j++)
			{
				numero=0;
				for(int k = 0; k < this.numerodecolumnas; k++)
					numero = numero + (this.Matriz[i][k] * MatrizTemp.Matriz[k][j]);
				Resultado.Matriz[i][j] = numero;
			}	
        }
        return Resultado;
	}

}

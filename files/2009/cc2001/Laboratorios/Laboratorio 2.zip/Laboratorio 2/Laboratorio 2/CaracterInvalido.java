 /** Esta clase representa una condicion de una excepcion en la cual las dimensiones de una matriz estan mal ingresadas
 * 
 * @author Carlos Lopez y Jefry Turcios
 * @version 01.02.09
 */
public class CaracterInvalido extends Exception
{
    private int filaenquefallo;
    private String datoinvalido;
    
    /**
     * Configura el objeto de la excepcion con algun mensaje de error
     */
    CaracterInvalido(String mensaje)
    {
        super(mensaje);
    }
    
    /**
     * Metodo que sirve para establecer el String invalido que se ingreso
     * 
     * @params datoinvalido El string invalido
     */
    public void setDatoInvalido(String datoinvalido){
        this.datoinvalido = datoinvalido;
    }

    /**
     * Metodo que sirve para devolver el String invalido que se ingreso
     * 
     * @return El string invalido
     */
    public String getDatoInvalido(){
        return this.datoinvalido;
    }
    
    /**
     * Metodo que sirve para establecer el numero de fila en donde se ingreso el String invalido
     * 
     * @params filaenquefalla La fila en donde esta el caracter invalido
     */
    public void setFilaenDondeEstaElDatoInvalido(int filaenquefallo){
        this.filaenquefallo = filaenquefallo;
    }

    /**
     * Metodo que sirve para devolver el numero de fila en donde se ingreso el String invalido
     * 
     * @return La fila en donde esta el caracter invalido
     */
    public int getFilaenDondeEstaElDatoInvalido(){
        return this.filaenquefallo;
    }
}

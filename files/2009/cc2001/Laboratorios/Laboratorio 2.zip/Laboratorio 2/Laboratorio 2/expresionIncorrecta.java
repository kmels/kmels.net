 /** Esta clase representa una condicion de una excepcion en la cual las expresion de una matriz esta mal ingresado
 * 
 * @author Carlos Lopez y Jefry Turcios
 * @version 01.02.09
 */
public class expresionIncorrecta extends Exception
{
    private int numerodeCorchetesCerrados;
    private int numerodeCorchetesAbiertos;
    /**
     * Configura el objeto de la excepcion con algun mensaje de error
     */
    expresionIncorrecta(String mensaje)
    {
        super(mensaje);
    }
    
    /**
     * Metodo para establecer el numero de corchetes cerrados
     * 
     * @param numerodeCorchetesCerrados el numero de corchetes cerrados en la expresion
     */
    public void setNumerodeCorchetesCerrados(int numerodeCorchetesCerrados){
        this.numerodeCorchetesCerrados = numerodeCorchetesCerrados;
    }
    
    /**
     * Metodo para devolver el numero de corchetes cerrados en la expresion
     * 
     * @return el numero de corchetes cerrados
     */
    public int getNumerodeCorchetesCerrados(){
        return (this.numerodeCorchetesCerrados);
    }
    
    /**
     * Metodo para establecer el numero de corchetes abiertos
     * 
     * @param numerodeCorchetesAbiertos el numero de corchetes abiertos en la expresion
     */
    public void setNumerodeCorchetesAbiertos(int numerodeCorchetesAbiertos){
        this.numerodeCorchetesAbiertos = numerodeCorchetesAbiertos;
    }
    
    /**
     * Metodo para devolver el numero de corchetes abiertos en la expresion
     * 
     * @return el numero de corchetes abiertos
     */
    public int getNumerodeCorchetesAbiertos(){
        return (this.numerodeCorchetesAbiertos);
    }
}

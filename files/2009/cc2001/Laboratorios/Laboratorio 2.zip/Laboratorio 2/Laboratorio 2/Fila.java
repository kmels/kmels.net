
/**
 * Esta es la clase de cada fila
 * 
 * @author Carlos Lopez y Jeffry Turcios
 * @version 01.02.09
 */
import java.util.ArrayList;
import java.util.StringTokenizer;

public class Fila
{
    public ArrayList<Integer> columnas;

    /**
     * Constructor para los objetos de la clase fila
     * @param valoresdelafila String de valores que 
     * @throws CaracterInvalido si encuentra algun caracter que no sea un numero
     */
    public Fila(String valoresdelafila) throws CaracterInvalido
    {
        columnas = new ArrayList<Integer>();
        StringTokenizer valores = new StringTokenizer(valoresdelafila);
        while (valores.hasMoreTokens()) {
            try {
                columnas.add(Integer.parseInt(valores.nextToken())); 
            } catch (NumberFormatException e){
                CaracterInvalido caracterInvalido = new CaracterInvalido("Usted ingreso un dato a su matriz que no es un numero entero");
                throw caracterInvalido;
            }
        }
    }
}

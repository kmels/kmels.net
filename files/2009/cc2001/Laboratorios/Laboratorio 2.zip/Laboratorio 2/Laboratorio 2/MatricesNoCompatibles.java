
/**
 * Esta clase representa una condicion de una excepcion en la cual las dimensiones de dos matrices que se estan intentando operar tienen diferentes dimensiones
 * 
 * @author Carlos Lopez y Jefry Turcios
 * @version 01.02.09
 */
public class MatricesNoCompatibles extends Exception
{
    /**
     * Configura el objeto de la excepcion con algun mensaje de error
     */
    MatricesNoCompatibles(String mensaje)
    {
        super(mensaje);
    }
}


/**
 * Clase Driver, la que maneja a crea a laboratorio 
 * 
 * @author Carlos Eduardo L�pez Camey
 * @version 01.02.09
 */
public class Driver
{
    static Lab2 Laboratorio;

    /**
     * Constructor for objects of class Driver
     * 
     * @throws expresionIncorrecta si se ingresa una expresion de matriz cuyo numero de "[" es diferente al numero de "]" 
     * @throws DimensionesIncorrectas si se ingresa una matriz cuyo numero de columnas no es igual en todas las filas ingresadas
     * @throws MuchasDimensiones si se ingresa una matriz cuyo numero de filas o el numero de columnas es mayor a 10 
     * @throws CaracterInvalido si ingreso un numero no entero, una letra o un caracter invalido como dato de la matriz ingresada
     */
    public static void main(String arg[]) throws expresionIncorrecta, DimensionesIncorrectas, MuchasDimensiones, CaracterInvalido{
        Laboratorio = new Lab2();
    }
}
